package today.Fine.ui.font;

import java.awt.Color;

import today.Fine.utils.render.RenderUtil;
import today.Fine.module.modules.render.HUD;


public class ColorSettings {

    static int x;
    static int y = 0;
    public static int color;
    static int ticks;

    public ColorSettings(){
        color = HUD.color.getValue().intValue();
    }

	public void render(int x, int y, int mouseX, int mouseY, boolean isKeyDown) {
        this.x=x;
        this.y=y;
        for(ticks = 0;ticks<50;ticks+=1) {
            Color rainbowcolor = new Color(Color.HSBtoRGB((float) (ticks / 50.0 + Math.sin(1.6)) % 1.0f, 0.5f, 1.0f));
            if(mouseX>x&&mouseX<x + 50&&mouseY>y&&mouseY<y+13 && isKeyDown){
                color = new Color(Color.HSBtoRGB((float) ((mouseX - x) / 50.0 + Math.sin(1.6)) % 1.0f, 0.5f, 1.0f)).getRGB();
                HUD.color.setValue((double)color);
                RenderUtil.drawRect(mouseX-1,mouseY-1,mouseX+1,mouseY+1,new Color(100,100,100,100).getRGB());
            }

            if(mouseX>x&&mouseX<x + 50&&mouseY>y&&mouseY<y+13){
                RenderUtil.drawRect(mouseX-1,mouseY-1,mouseX+1,mouseY+1,new Color(100,100,100,100).getRGB());
            }

            RenderUtil.drawRect(x + ticks, y, x + ticks + 1, y + 13, rainbowcolor.getRGB());
            RenderUtil.drawRect(x , y+16, x + 50, y + 20,color);
        }
        if (++ticks > 50) {
            ticks = 0;
        }
    }
}

